__version__ = "2.0.0"

from .__main__ import *
from .classes import *